from django.apps import AppConfig


class GymappConfig(AppConfig):
    name = 'gym-api'
